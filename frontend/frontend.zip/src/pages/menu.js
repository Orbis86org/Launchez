const menus = [
    {
        id: 1,
        name: 'Home',
        links: '/',
    },
    {
        id: 2,
        name: 'Create Token',
        links: '/create',
    },

]

export default menus;