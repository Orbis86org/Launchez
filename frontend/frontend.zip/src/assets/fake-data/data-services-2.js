

import img1 from '../images/icon/manager.png'
import img2 from '../images/icon/Lock.png'
import img3 from '../images/icon/smartphone.png'
const dataServices2 = [
    {
        id: 1,
        icon: img1,
        title: 'Manage your portfolio',
        text: 'Buy And Sell Popular Digital Currencies, Keep Track Of Them In The One Place.',
        active: 'active',
        bg:''
    },
    {
        id: 2,
        icon: img2,
        title: 'Recurring buys',
        text: 'Invest In Cryptocurrency Slowly Over Time By Scheduling Buys Daily, Weekly, Or Monthly.',
        active: '',
        bg:'green'
    },
    {
        id: 3,
        icon: img3,
        title: 'Mobile apps',
        text: 'Stay On Top Of The Markets With The Cryptolly App For Android Or IOS.',
        active: '',
        bg:'blue'
    },
   
]

export default dataServices2;