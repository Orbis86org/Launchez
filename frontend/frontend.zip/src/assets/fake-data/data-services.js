

import img1 from '../images/icon/manager.png'
import img2 from '../images/icon/Lock.png'
import img3 from '../images/icon/smartphone.png'
const dataServices = [
    {
        id: 1,
        icon: img1,
        title: 'Portfolio Manager',
        text: 'Buy And Sell Popular Digital Currencies, Keep Track Of Them In The One Place.'
    },
    {
        id: 2,
        icon: img2,
        title: 'Vault protection',
        text: 'For Added Security, Store Your Funds In A Vault With Time Delayed Withdrawals.'
    },
    {
        id: 3,
        icon: img3,
        title: 'Mobile Apps',
        text: 'Stay On Top Of The Markets With The Cryptolly App For Android Or IOS.'
    },
   
]

export default dataServices;