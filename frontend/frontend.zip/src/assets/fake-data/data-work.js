

import img1 from '../images/icon/Cloud.png';
import img2 from '../images/icon/Wallet.png';
import img3 from '../images/icon/Mining.png';
import img4 from '../images/icon/Comparison.png';

const dataWork = [
    {
        id: 1,
        img: img1,
        step: 'Step 1',
        title: 'Download',
        text: 'Stacks is a production-ready library of stackable content blocks built in React Native.'
    },
    {
        id: 2,
        img: img2,
        step: 'Step 2',
        title: 'Connect wallet',
        text: 'Stacks is a production-ready library of stackable content blocks built in React Native.'
    },
    {
        id: 3,
        img: img3,
        step: 'Step 3',
        title: 'Start trading',
        text: 'Stacks is a production-ready library of stackable content blocks built in React Native.'
    },
    {
        id: 4,
        img: img4,
        step: 'Step 4',
        title: 'Start trading',
        text: 'Stacks is a production-ready library of stackable content blocks built in React Native.'
    },
   
]

export default dataWork;